package implant.lata.com.dumetschool;

/**
 * Created by Sami on 4/8/2017.
 */

public interface ReadOperationDelegate  {
    void seeMoreButtonTapped(Item post);
}

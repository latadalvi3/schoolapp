package implant.lata.com.dumetschool;

/**
 * Created by Sami on 4/9/2017.
 */

public interface ProductOperationDelegate {
    void claimThisDealTapped(ProductVo productVo);
}

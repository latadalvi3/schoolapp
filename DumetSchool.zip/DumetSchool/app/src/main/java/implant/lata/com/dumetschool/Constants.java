package implant.lata.com.dumetschool;

/**
 * Created by Sami on 4/8/2017.
 */

public class Constants {
    public static final int readMorecode =3333;
    public static String requestCodeKey = "request_key";
    public static final String PREFS_NAME1 = "AOP_PREFS";


}

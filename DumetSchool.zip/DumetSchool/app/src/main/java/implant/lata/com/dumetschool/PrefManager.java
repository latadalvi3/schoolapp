package implant.lata.com.dumetschool;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by lata on 13/5/17.
 */

class PrefManager {
    // method to add new id of  postcategory
    static void addID(int id, Context context) {
        Set<Integer> array = PrefManager.getArrayOfSelectedCategories(context);
        array.add(id);
        PrefManager.saveSelectedCategories(array, context);
    }

    // method to delete id of  postcategory
    static void deleteID(int id, Context context) {
        Set<Integer> array = PrefManager.getArrayOfSelectedCategories(context);
        array.remove(id);
        PrefManager.saveSelectedCategories(array, context);
    }

    // method to get post category array
    static Set<Integer> getArrayOfSelectedCategories(Context context) {
        // read previous array string from shared pref
        SharedPreferences settings = context.getSharedPreferences(Constants.PREFS_NAME1, Context.MODE_PRIVATE);
        String arrayString = settings.getString(context.getString(R.string.array_for_category), null);
        if (arrayString != null && !arrayString.isEmpty()) {
            // convert string to set of integers
            String[] tokens= arrayString.split(",");
            Set<Integer> array = new HashSet<Integer>();
            for (String token : tokens) {
                array.add(Integer.parseInt(token));
            }
            return array;
        } else {
            return new HashSet<Integer>();
        }
    }

    // method to save post category array
    static void saveSelectedCategories(Set<Integer> set, Context context) {
        // convert set to string
        StringBuilder builder = new StringBuilder();
        for (Integer s : set) {
            builder.append(s).append(",");
        }

        // save string in shared pref
        SharedPreferences settings = context.getSharedPreferences(Constants.PREFS_NAME1, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(context.getString(R.string.array_for_category), builder.toString());  //3
        editor.commit();
    }
}

